
export class Logger {
    static log(message: string) {
        console.log(message);
    }
}
